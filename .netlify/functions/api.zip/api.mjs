
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/api.mjs
var SITE_ID = "658f40e1-9d0f-4072-80a5-d6d0eb35d77e";
var STORE = "sq3";
var ADMIN_PIN = process.env.ADMIN_PIN || "1234";
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}
async function blobGet(token, key) {
  const r = await fetch(`https://api.netlify.com/api/v1/blobs/${SITE_ID}/${STORE}/${key}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (r.status === 404) return null;
  if (!r.ok) return null;
  return r.json();
}
async function blobSet(token, key, value) {
  const r = await fetch(`https://api.netlify.com/api/v1/blobs/${SITE_ID}/${STORE}/${key}`, {
    method: "PUT",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify(value)
  });
  if (!r.ok) throw new Error(`Blob write failed: ${r.status}`);
}
var api_default = async (req, context) => {
  const url = new URL(req.url);
  const path = url.pathname;
  const method = req.method.toUpperCase();
  const token = process.env.NETLIFY_TOKEN;
  const emptyBoard = { owners: {}, rowNums: null, colNums: null, numbersLocked: false };
  if (path === "/api/squares" && method === "GET") {
    const gameId = url.searchParams.get("gameId");
    if (!gameId) return json({ error: "Missing gameId" }, 400);
    if (!token) return json(emptyBoard);
    try {
      const data = await blobGet(token, gameId) || emptyBoard;
      return json(data);
    } catch (err) {
      return json({ owners: {}, error: err.message });
    }
  }
  if (path === "/api/claim-square" && method === "POST") {
    if (!token) return json({ error: "Server not configured (missing NETLIFY_TOKEN)" }, 500);
    let body;
    try {
      body = await req.json();
    } catch {
      return json({ error: "Invalid JSON body" }, 400);
    }
    const { gameId, indices, initials } = body;
    if (!gameId || !Array.isArray(indices) || !initials) {
      return json({ error: "Missing gameId, indices, or initials" }, 400);
    }
    if (initials.length < 2 || initials.length > 6) {
      return json({ error: "Initials must be 2-6 characters" }, 400);
    }
    try {
      const data = await blobGet(token, gameId) || emptyBoard;
      const owners = data.owners || {};
      const conflicts = indices.filter((i) => owners[i] !== void 0);
      if (conflicts.length > 0) {
        return json({ error: `Squares already taken: ${conflicts.join(", ")}` }, 409);
      }
      indices.forEach((i) => {
        owners[i] = initials.toUpperCase();
      });
      data.owners = owners;
      await blobSet(token, gameId, data);
      return json({ ok: true, claimed: indices, initials: initials.toUpperCase() });
    } catch (err) {
      return json({ error: err.message }, 500);
    }
  }
  if (path === "/api/lock-numbers" && method === "POST") {
    if (!token) return json({ error: "Server not configured (missing NETLIFY_TOKEN)" }, 500);
    let body;
    try {
      body = await req.json();
    } catch {
      return json({ error: "Invalid JSON body" }, 400);
    }
    const { gameId, pin, rowNums, colNums } = body;
    if (!gameId || !pin || !rowNums || !colNums) {
      return json({ error: "Missing required fields" }, 400);
    }
    if (pin !== ADMIN_PIN) return json({ error: "Invalid PIN" }, 403);
    if (!Array.isArray(rowNums) || rowNums.length !== 10 || !Array.isArray(colNums) || colNums.length !== 10) {
      return json({ error: "rowNums and colNums must each be arrays of 10" }, 400);
    }
    try {
      const data = await blobGet(token, gameId) || emptyBoard;
      data.rowNums = rowNums;
      data.colNums = colNums;
      data.numbersLocked = true;
      await blobSet(token, gameId, data);
      return json({ ok: true });
    } catch (err) {
      return json({ error: err.message }, 500);
    }
  }
  if (path === "/api/reset-squares" && method === "POST") {
    if (!token) return json({ error: "Server not configured (missing NETLIFY_TOKEN)" }, 500);
    let body;
    try {
      body = await req.json();
    } catch {
      return json({ error: "Invalid JSON body" }, 400);
    }
    const { gameId, pin } = body;
    if (!gameId || !pin) return json({ error: "Missing gameId or pin" }, 400);
    if (pin !== ADMIN_PIN) return json({ error: "Invalid PIN" }, 403);
    try {
      await blobSet(token, gameId, emptyBoard);
      return json({ ok: true });
    } catch (err) {
      return json({ error: err.message }, 500);
    }
  }
  return json({ error: `No handler for ${method} ${path}` }, 404);
};
var config = {
  path: ["/api/squares", "/api/claim-square", "/api/lock-numbers", "/api/reset-squares"]
};
export {
  config,
  api_default as default
};
